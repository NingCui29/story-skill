# Story Skill 0.6.19

This npm package contains eight sibling skills: `story-skill/`, `story-skill-plan/`, `story-skill-write/`, `story-skill-analyze/`, `story-skill-review/`, `story-skill-research/`, `story-skill-cover/`, `story-skill-publish/`. Its 62 skill files preserve the exact bytes of the input ZIP.

This wrapper follows the input ZIP's license files and does not replace or relicense previously published Release or Packages artifacts.

npm distributes content; installing this package does not register skills with the host app. Copy all eight complete skill directories into the host's skills directory (for example `.agents/skills/` for Codex, `.qoder/skills/` for Qoder, `.zcode/skills/` for ZCode, `.workbuddy/skills/` for WorkBuddy AI, `.trae/skills/` for TRAE IDE, `.cursor/skills/` for Cursor, or `.opencode/skills/` for OpenCode projects), or follow the repository's managed installation instructions for the host and scope. User directories can differ from project directories; use INSTALL.md's host table. Do not copy only an individual task skill: its shared runtime is required.

For macOS, Linux and Windows, use the managed installation instructions that accompany this source or input ZIP, and validate it in an isolated directory before replacing an installation.

The shared Python runtime is `story-skill/scripts/story.py`; npm does not install Python. Project data and novels belong outside the skill installation directory.

The publication skill prepares local snapshots and records only; it does not log in to author platforms, upload chapters or publish them remotely.

GitHub Packages npm downloads require authentication. See https://github.com/NingCui29/story-skill for setup and update instructions.

License: Story Skill Non-Commercial Use and Commercial Licensing Agreement. Non-commercial use is permitted under the agreement; commercial use requires a separate paid authorization. See the top-level `LICENSE` and each skill's complete `LICENSE`.
